# 3 Landing Pages para venda

Pacote com três templates independentes:
- 01 Agência Digital Premium
- 02 Academia Fitness
- 03 Restaurante Gourmet

Cada pasta contém `index.html`, `style.css`, `script.js` e `LEIA-ME.txt`.

## Personalização
Antes de vender ou entregar ao cliente, substitua os dados de demonstração:
- WhatsApp `5500000000000`
- endereço, telefone, horários e preços
- nome da marca, textos e redes sociais
- elementos visuais ilustrativos por fotografias licenciadas ou fornecidas pelo cliente

## Visualização
Abra o `index.html` de cada pasta em um navegador. Não é necessário instalar Node.js.
